package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Item;

@WebServlet("/ProductDetailServlet")
public class chitietitem extends HttpServlet {

    // Hàm tạo list sản phẩm dùng chung
    private ArrayList<Item> getAllItems() {
        ArrayList<Item> items = new ArrayList<>();
        items.add(new Item("Nokia 2020", "1.png", 500, 0.1));
        items.add(new Item("Samsung Xyz", "2.png", 700, 0.15));
        items.add(new Item("iPhone Xy", "3.png", 900, 0.25));
        items.add(new Item("Sony Erricson", "4.png", 55, 0.3));
        items.add(new Item("Seamen", "5.png", 70, 0.5));
        items.add(new Item("Oppo 2021", "6.png", 200, 0.2));
        return items;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("id");   // id là tên sản phẩm

        // 1. Không có id -> hiển thị danh sách (listproduct.jsp)
        if (name == null || name.isBlank()) {
            ArrayList<Item> items = getAllItems();
            req.setAttribute("items", items);

            // list tên để hiển thị bảng ds phía dưới
            ArrayList<String> ds = new ArrayList<>();
            for (Item it : items) {
                ds.add(it.getName());
            }
            req.setAttribute("ds", ds);

            req.getRequestDispatcher("/listproduct.jsp").forward(req, resp);
            return;
        }

        // 2. Có id -> hiển thị chi tiết (detailtu.jsp)
        ArrayList<Item> items = getAllItems();
        ArrayList<Item> selectedItems = new ArrayList<>();
        for (Item item : items) {
            if (item.getName().equalsIgnoreCase(name)) {
                selectedItems.add(item);
            }
        }
        req.setAttribute("selectedItems", selectedItems);
        req.getRequestDispatcher("/detailtu.jsp").forward(req, resp);
    }
}

package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.model.Items;
@WebServlet("/bai1jstl")
public class Bai1controller extends HttpServlet {
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	 req.setAttribute("lan", 19);

     ArrayList<String> danhsach = new ArrayList<String>();
     danhsach.add("Cần");
     danhsach.add("Cũ");
     danhsach.add("Siêng");
     danhsach.add("Năng");
     req.setAttribute("ds", danhsach);

     ArrayList<Items> items = new ArrayList<>();
     items.add(new Items("Nokia 2020", "1.png", 500, 0.1));
     items.add(new Items("Samsung Xyz", "2.png", 700, 0.15));
     items.add(new Items("iPhone Xy", "3.png", 900, 0.25));
     items.add(new Items("Sony Erricson", "4.png", 55, 0.3));
     items.add(new Items("Seamen", "5.png", 70, 0.5));
     items	.add(new Items("Oppo 2021", "6.png", 200, 0.2));
     req.setAttribute("items", items);

     // forward 1 lần — khuyến nghị dùng đường dẫn bắt đầu bằng '/'
     req.getRequestDispatcher("/jstlcb.jsp").forward(req, resp);
 }
}

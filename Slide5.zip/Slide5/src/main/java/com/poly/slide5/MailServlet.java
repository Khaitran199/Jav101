package com.poly.slide5;

import java.io.IOException;

import com.poly.slide5.util.Mailer;

import jakarta.mail.MessagingException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/mail/form", "/mail/send"})
public class MailServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/mail-form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        // TODO: thay tài khoản thật khi chạy
        String user = "khaitqts002101@gmail.com";
        String pass = "your-app-password";

        String message;
        try {
            Mailer mailer = new Mailer(user, pass);
            mailer.send(to, subject, body);
            message = "Gửi mail thành công!";
        } catch (MessagingException e) {
            e.printStackTrace();
            message = "Gửi mail thất bại: " + e.getMessage();
        }

        req.setAttribute("msg", message);
        req.getRequestDispatcher("/WEB-INF/views/mail-form.jsp").forward(req, resp);
    }
}

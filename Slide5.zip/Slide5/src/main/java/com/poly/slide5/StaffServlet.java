package com.poly.slide5;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Date;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet({"/staff/form", "/staff/save"})
@MultipartConfig
public class StaffServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads";

    @Override
    public void init() throws ServletException {
        // register Date converter for BeanUtils
        DateConverter dc = new DateConverter();
        dc.setPattern("yyyy-MM-dd");
        ConvertUtils.register(dc, Date.class);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // just show form
        req.getRequestDispatcher("/WEB-INF/views/staff-form.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");

        Staff staff = new Staff();
        try {
            BeanUtils.populate(staff, req.getParameterMap());
        } catch (Exception e) {
            throw new ServletException("Cannot populate bean", e);
        }

        // handle upload photo
        Part photoPart = req.getPart("photo");
        if (photoPart != null && photoPart.getSize() > 0) {
            String filename = Paths.get(photoPart.getSubmittedFileName())
                                   .getFileName().toString();
            String appPath = req.getServletContext().getRealPath("");
            String uploadPath = appPath + File.separator + UPLOAD_DIR;
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            File dest = new File(uploadDir, filename);
            photoPart.write(dest.getAbsolutePath());
            staff.setPhoto(UPLOAD_DIR + "/" + filename);
        }

        req.setAttribute("staff", staff);
        req.getRequestDispatcher("/WEB-INF/views/staff-result.jsp").forward(req, resp);
    }
}

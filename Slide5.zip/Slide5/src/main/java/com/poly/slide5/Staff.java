package com.poly.slide5;

import java.util.Date;

public class Staff {
    private String fullname;
    private Integer age;
    private Boolean gender;
    private Date recruit;
    private String country;
    private String photo;
    private Double salary;

    public Staff() {
    }

    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
    public Integer getAge() {
        return age;
    }
    public void setAge(Integer age) {
        this.age = age;
    }
    public Boolean getGender() {
        return gender;
    }
    public void setGender(Boolean gender) {
        this.gender = gender;
    }
    public Date getRecruit() {
        return recruit;
    }
    public void setRecruit(Date recruit) {
        this.recruit = recruit;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getPhoto() {
        return photo;
    }
    public void setPhoto(String photo) {
        this.photo = photo;
    }
    public Double getSalary() {
        return salary;
    }
    public void setSalary(Double salary) {
        this.salary = salary;
    }
}

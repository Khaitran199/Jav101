package com.poly.slide5;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet({"/auth/login", "/auth/home"})
public class CookieSessionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getServletPath();
        if ("/auth/home".equals(path)) {
            HttpSession session = req.getSession(false);
            if (session == null || session.getAttribute("user") == null) {
                resp.sendRedirect(req.getContextPath() + "/auth/login");
                return;
            }
            req.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(req, resp);
            return;
        }

        // login form: đọc cookie "user" nếu có
        String remembered = null;
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie ck : cookies) {
                if ("user".equals(ck.getName())) {
                    byte[] decoded = Base64.getDecoder().decode(ck.getValue());
                    remembered = new String(decoded, StandardCharsets.UTF_8);
                    break;
                }
            }
        }
        req.setAttribute("rememberedUser", remembered);
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String username = req.getParameter("username");
        String remember = req.getParameter("remember");

        // Demo: chấp nhận mọi username, không kiểm tra mật khẩu
        HttpSession session = req.getSession();
        session.setAttribute("user", username);

        // Ghi cookie nếu được chọn
        if ("on".equals(remember)) {
            String encoded = Base64.getEncoder()
                                   .encodeToString(username.getBytes(StandardCharsets.UTF_8));
            Cookie ck = new Cookie("user", encoded);
            ck.setPath(req.getContextPath());
            ck.setMaxAge(7 * 24 * 60 * 60); // 7 ngày
            resp.addCookie(ck);
        }

        resp.sendRedirect(req.getContextPath() + "/auth/home");
    }
}
